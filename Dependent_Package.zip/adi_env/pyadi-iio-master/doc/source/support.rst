Support
===================

Question and general support related to pyadi-iio should be ask in the `Software Interface Tools <https://ez.analog.com/sw-interface-tools/>`_ forum at `ADI's EngineerZone <https://ez.analog.com>`_. Code bugs or enhancement requests should be submitted through `GitHub issues <https://github.com/analogdevicesinc/pyadi-iio/issues>`_ for the repository itself.
