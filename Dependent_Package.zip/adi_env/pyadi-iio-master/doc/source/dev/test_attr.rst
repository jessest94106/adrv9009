Attribute Tests
=================

Functions used by test fixtures for evaluating attributes and driver state.

.. automodule:: test.attr_tests
   :members:
