Generic Tests
=================

Functions used by test fixtures for evaluating drivers without pyadi-iio classes or not by using pyadi-iio classes.

.. automodule:: test.generics
   :members:
