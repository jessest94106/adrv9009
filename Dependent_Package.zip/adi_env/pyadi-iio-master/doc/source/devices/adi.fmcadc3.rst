adi.fmcadc3 module
==================

.. automodule:: adi.fmcadc3
   :members:
   :undoc-members:
   :show-inheritance:
