ad719x
=================

.. automodule:: adi.ad719x
   :members:
   :undoc-members:
   :show-inheritance:
