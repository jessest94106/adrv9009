adxl313
==================

.. automodule:: adi.adxl313
   :members:
   :undoc-members:
   :show-inheritance:
