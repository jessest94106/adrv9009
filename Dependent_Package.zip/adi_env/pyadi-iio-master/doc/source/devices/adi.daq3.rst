daq3
===============

.. automodule:: adi.daq3
   :members:
   :undoc-members:
   :show-inheritance:
