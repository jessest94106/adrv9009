adxl345
==================

.. automodule:: adi.adxl345
   :members:
   :undoc-members:
   :show-inheritance:
