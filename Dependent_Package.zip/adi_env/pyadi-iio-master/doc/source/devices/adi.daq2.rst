daq2
===============

.. automodule:: adi.daq2
   :members:
   :undoc-members:
   :show-inheritance:
