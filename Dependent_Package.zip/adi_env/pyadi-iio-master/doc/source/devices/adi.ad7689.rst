ad7689
=================

.. automodule:: adi.ad7689
   :members:
   :undoc-members:
   :show-inheritance:
