adi.cn0511 module
=================

.. automodule:: adi.cn0511
   :members:
   :undoc-members:
   :show-inheritance:
