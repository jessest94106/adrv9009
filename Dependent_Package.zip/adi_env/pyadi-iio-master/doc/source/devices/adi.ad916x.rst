adi.ad9166 module
=================

.. automodule:: adi.ad916x
   :members:
   :undoc-members:
   :show-inheritance:
