adi.ad9250 module
=================

.. automodule:: adi.ad9250
   :members:
   :undoc-members:
   :show-inheritance:
