jesd
===============

.. automodule:: adi.jesd
   :members:
   :undoc-members:
   :show-inheritance:
