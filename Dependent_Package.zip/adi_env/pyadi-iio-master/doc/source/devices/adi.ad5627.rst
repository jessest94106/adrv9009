ad5627
=================

.. automodule:: adi.ad5627
   :members:
   :undoc-members:
   :show-inheritance:
