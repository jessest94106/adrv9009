adi.ad9434 module
=================

.. automodule:: adi.ad9434
   :members:
   :undoc-members:
   :show-inheritance:
