gen\_mux
===================

.. automodule:: adi.gen_mux
   :members:
   :undoc-members:
   :show-inheritance:
