adxl355
==================

.. automodule:: adi.adxl355
   :members:
   :undoc-members:
   :show-inheritance:
