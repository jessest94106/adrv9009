ad7124
=================

.. automodule:: adi.ad7124
   :members:
   :undoc-members:
   :show-inheritance:
