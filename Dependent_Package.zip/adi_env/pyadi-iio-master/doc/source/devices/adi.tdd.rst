tdd
=================

.. automodule:: adi.tdd
   :members:
   :undoc-members:
   :show-inheritance:
