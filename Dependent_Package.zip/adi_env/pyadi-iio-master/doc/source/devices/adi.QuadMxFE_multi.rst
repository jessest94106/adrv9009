QuadMxFE\_multi
==========================

.. automodule:: adi.QuadMxFE_multi
   :members:
   :undoc-members:
   :show-inheritance:
