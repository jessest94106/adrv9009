adar1000
===================

.. automodule:: adi.adar1000
   :members:
   :undoc-members:
   :show-inheritance:
