adi.ad5940 module
=================

.. automodule:: adi.ad5940
   :members:
   :undoc-members:
   :show-inheritance:
