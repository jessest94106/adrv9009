adi.ad9265 module
=================

.. automodule:: adi.ad9265
   :members:
   :undoc-members:
   :show-inheritance:
