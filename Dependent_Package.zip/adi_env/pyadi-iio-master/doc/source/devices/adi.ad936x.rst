ad936x
=================

.. automodule:: adi.ad936x
   :members:
   :undoc-members:
   :show-inheritance:
