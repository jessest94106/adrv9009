adi.adg2128 module
==================

.. automodule:: adi.adg2128
   :members:
   :undoc-members:
   :show-inheritance:
