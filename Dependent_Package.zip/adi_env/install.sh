#!/bin/sh
dpkg -i libserialport0_0.1.1-1_arm64.deb
dpkg -i libpython3.7-minimal_3.7.0_b3-1_arm64.deb
dpkg -i python3.7-minimal_3.7.0_b3-1_arm64.deb
dpkg -i libpython3.7-stdlib_3.7.0_b3-1_arm64.deb
dpkg -i python3.7_3.7.0_b3-1_arm64.deb
dpkg -i Ubuntu-arm64v8_latest_master_libiio.deb
dpkg -i python3-numpy_1.13.3-2ubuntu1_arm64.deb
cd pyadi-iio-master/pyadi-iio-master
python3 setup.py install
cd ../..
cd pylibiio-0.23.1
python3 setup.py install

